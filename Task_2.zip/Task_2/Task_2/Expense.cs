﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Task_2
{
    class Expense
    {
        //delegate void Exceed(List<double> totalExpenses, int income);

        private int income;
        private List<double> expenses = new List<double>();        

        public Expense()
        {
            income = 0;
        }

        public Expense(int income, List<double> expenses)
        {
            this.income = income;
            this.expenses = expenses;
        }

        public int Income
        {
            set { income = value; }
            get { return income; }
        }

        public List<double> Expenses
        {
            get { return expenses; }

            set
            {                                                                    //here I tried to implement a more efficient way of doing the delegate that would sit in the set method so that every time the 
                //Exceed del = CheckExceed;                                     //the list was updated the delegate would be called but it would not work. The setter is only for setting and no other code.
                //del.Invoke(expenses, Income);
                expenses = value;
            }            
        }

        /*public static void CheckExceed(List<double> totalExpenses, int income)
        {
            Console.Write("Test");          

            if ((totalExpenses.Sum(x => Convert.ToDouble(x))) > (income * 0.75))
            {
                Console.WriteLine("You have exceeded 75% of your gross monthly income on expenses.");
                System.Environment.Exit(0);
            }
        }*/
    }
}
