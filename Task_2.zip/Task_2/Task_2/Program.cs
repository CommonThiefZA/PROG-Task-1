﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Task_2
{
    class Program
    {
        delegate void Exceed(List<double> test, int income);                    //delegate that takes the list and income as parameters 

        static void Main(string[] args)
        {
            Loan exp = new Loan();                                              //objects declarations for the different classes
            Rental rnt = new Rental();
            CarLoan car = new CarLoan();
            double totalExpenses;            

            getInput(exp, rnt, car);
            totalExpenses = getTotalExpenses(exp);
            displayOutput(exp, rnt, car, totalExpenses);                        // various functions to perform the tasks

            Console.ReadKey();
        }

        public static void getInput(Loan exp, Rental rnt, CarLoan car)
        {

            int months;

            Exceed del = TestExceed;

            Console.Write("Enter the following details regarding your expenses : \n***************************\n\n");
            Console.Write("Enter your gross monthly income : R ");
            exp.Income = Convert.ToInt32(Console.ReadLine());            
            Console.Write("Enter your monthly tax : R ");            
            exp.Expenses.Add(Convert.ToInt32(Console.ReadLine()));
            del(exp.Expenses, exp.Income);                                      //delegate is called everytime a user adds a new expense to the list.
            Console.Write("Enter your monthly groceries expenses : R ");
            exp.Expenses.Add(Convert.ToInt32(Console.ReadLine()));
            del(exp.Expenses, exp.Income);                                      
            Console.Write("Enter your monthly utilities expenses : R ");
            exp.Expenses.Add(Convert.ToInt32(Console.ReadLine()));
            Console.Write("Enter your monthly travel expenses: R ");            //these lines get the user input and sends them to the object class to be set
            exp.Expenses.Add(Convert.ToInt32(Console.ReadLine()));
            del(exp.Expenses, exp.Income);
            Console.Write("Enter your monthly phone expenses: R ");
            exp.Expenses.Add(Convert.ToInt32(Console.ReadLine()));
            del(exp.Expenses, exp.Income);
            Console.Write("Enter your monthly other expenses: R ");
            exp.Expenses.Add(Convert.ToInt32(Console.ReadLine()));
            del(exp.Expenses, exp.Income);

            Console.WriteLine("\nEnter  your living status :\n(1) Renting\n(2) Buying");              // this prompts the user to enter a value based on if they are paying rent or a bond

            switch (Convert.ToInt32(Console.ReadLine()))                         //switch case the output based on what the user entered 
            {
                case 1:
                    rnt.Renting = true;
                    Console.Write("\n\nEnter the montly rental cost : R ");     //here the user has chosen rent so th system prompts them to enter their monthly rent
                    rnt.MonthlyRent = Convert.ToInt32(Console.ReadLine());
                    exp.Expenses.Add(rnt.MonthlyRent);
                    del(exp.Expenses, exp.Income);
                    break;
                case 2:                                                         //case 2 is where the user wants a bond and all the details are asked and then sent to the object class to be set 
                    rnt.Renting = false;
                    Console.Write("\n\nEnter the total value of the property : R ");
                    exp.PurchaseHouse = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter the deposit paid: R ");
                    exp.DepositHouse = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter the monthly interest rate : ");
                    exp.RateHouse = Convert.ToDouble(Console.ReadLine());
                    Console.Write("Enter the total period of months you will be paying the bond off in (between 240 and 360) : ");
                    months = exp.Months = Convert.ToInt32(Console.ReadLine()); ;
                    if ((months > 360) || (months < 240)) //this will check to make sure the user has enter between 240-360 for their months
                    {
                        Console.WriteLine("Error! Enter a valid number of months (between 240 and 360.)");
                        System.Environment.Exit(0);
                    }
                    else
                    {
                        exp.Months = months;
                    }

                    exp.calcHouseExpense();
                    exp.Expenses.Add(exp.Bond);
                    del(exp.Expenses, exp.Income);

                    break;
                default:
                    Console.WriteLine("Error! Enter a valid option for rent."); //this default line is if the user inputs anything other than 1 or 2
                    System.Environment.Exit(0);                                 //this will exit the application
                    break;
            }            

            Console.WriteLine("\n\nWould you like to add a car payment?\n(y) Yes : (n) No");

            if(Console.ReadLine() == "y")       //this method will execute if the user has chosen to add a car payment to their expenses tally
            {
                car.Car = true;
                Console.Write("\n\nEnter the name of the model and make of the car : ");
                car.Model = Console.ReadLine();
                Console.Write("Enter The total price of the car : R ");
                car.PurchaseCar = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the deposit you paid : R ");
                car.DepositCar = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the interst rate for the loan in % format : ");
                car.RateCar = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter the monthly insurance cost for the car : R ");
                car.Insurance = Convert.ToInt32(Console.ReadLine());
                exp.Expenses.Add(car.calcCarExpense());
                del(exp.Expenses, exp.Income);
            }
            else
            {
                car.Car = false;
            }
            
        }

        public static double getTotalExpenses(Loan exp)                     //this methods gets the total expenses from the HomeLoan and Expense Class and then minuses that    
        {                                                                       //from the gross income to calculate the final money left over at the end of the month
            double output = 0;
            double expenses = 0;

            expenses = exp.Expenses.Sum(x => Convert.ToDouble(x));

            output = exp.Income - expenses;

            return output;
        }

        public static void displayOutput(Loan exp, Rental rnt, CarLoan car, double total)                          //this method is simply to display the output and a breakdown of the expenses as well as format any expences with decimals
        {
            double expenses = 0;
            expenses = exp.Expenses.Sum(x => Convert.ToDouble(x));

            //expenses breakdown

            Console.WriteLine("\n\nExpenses Breakdown : \n***************************\n");
            Console.WriteLine($"All Expenses : R {expenses.ToString("0.00")}\n\nBreakdown\n***************************\n");

            if (rnt.Renting)
            {
                Console.WriteLine($"Monthly Rent rayment: R {rnt.MonthlyRent.ToString("0.00")}");
            }
            else
            {
                Console.WriteLine($"Monthly Bond payment : R {exp.Bond.ToString("0.00")}");
            }

            if(car.Car)
            {
                Console.WriteLine($"Monthly Car Payment for the {car.Model} (including insurance) is : R {car.CarMonthly.ToString("0.00")}");
            }
            else
            {
                Console.WriteLine("No Car payment made.");
            }

            Console.WriteLine($"Other Monthly Expenses : R {(expenses - rnt.MonthlyRent - exp.Bond - car.CarMonthly - exp.Expenses[0]).ToString("0.00")}");
            Console.WriteLine($"Tax : R {exp.Expenses[0].ToString("0.00")}");

            Console.WriteLine($"\n\nThe total amount of money you will have left for the month is : R {total.ToString("0.00")} ");

            Console.WriteLine("\n***************************\n\nExpenses in Decending order of price\n\n");
                       
            exp.Expenses.Reverse();// this function sorts the list into descending order 

            foreach(double k in exp.Expenses)// this will display the expenses in descending order.
            {
                Console.WriteLine($"R : {k.ToString("0.00")}");
            }

        }

        public static void TestExceed(List<double> test, int income)            //This is the delegate method that checks the total expenses vs the 75% limit
        {
            if(test.Sum(x => Convert.ToDouble(x)) > (income * 0.75))//A message will be displayed in the console once they have exceeded 75% of their income
            {
                Console.WriteLine("You have exceeded 75% of your gross monthly income on expenses.");
                //System.Environment.Exit(0);
            }
        }
    }
}

